# Joel's photographic sprite assets

`assets/` contains nine aligned head PNGs, two hand PNGs, and the source/alignment manifest.
Directions are viewer-relative. Head frames use a 640 × 800 canvas and a (320, 752) neck pivot.

Copy `components/` into a React app and `assets/` into its public directory as `joel/`:

    import { FloatingPortrait } from './components/FloatingPortrait';
    <FloatingPortrait assetPath="/joel" size={200} motionStrength={0.8} />

The component includes its stylesheet. No runtime image processing or external service is needed.

`masks/` contains editable grayscale source-crop masks (white=opaque, black=transparent).
`frames.json` records source filenames, crop coordinates, alignment, and refinement annotations.
Automatic masks came from BiRefNet; the hand edge masks use local GrabCut refinement.
Photo RGB was preserved. Original HEIC photos are not included in this bundle.

The complete local demo, processing scripts, and rebuild instructions are in the original workspace.
